const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const blog=require('../controllers/blogcontroller')
const handlelogin=require('../helper/logincheckfunction')
const checksubscription=require('../helper/checksubscription')
const upload=require('../helper/multer')




router.get('/',regc.loginpage)
router.post('/',regc.logincheck)
router.get('/reg',regc.regpage)
router.post('/reg',regc.register)
router.get('/emailverify/:id',regc.emailsendlink)
router.get('/forgotform',regc.forgotform)
router.post('/forgotform',regc.forgotsendlink)
router.get('/forgotpasswordlink/:id',regc.forgotpasslink)
router.post('/forgotpasswordlink/:id',regc.forgotpasschange)
router.get('/logout',regc.logout)
router.get('/userprofiles',regc.userprofiles)
router.get('/profile',handlelogin,regc.profileupdateform)
router.post('/profile',handlelogin,upload.single('img'),regc.profileupdate)

router.get('/yourblog',handlelogin,blog.blogselection)
router.get('/blogadd',handlelogin,blog.blogform)
router.post('/blogadd',blog.blogadd)
router.get('/allblog',blog.allblog)
router.get('/blogdelete/:id',blog.blogdelete)
router.get('/blogupdate/:id',blog.blogupdateform)
router.get('/contactdetails/:id',checksubscription,regc.contactdetails)





module.exports=router
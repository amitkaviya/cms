const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const blog=require('../controllers/blogcontroller')
const handlelogin=require('../helper/logincheckfunction')


router.get('/dashboard',handlelogin,(req,res)=>{
    const username=req.session.username
res.render('admin/dashboard.ejs',{username})
})


router.get('/user',handlelogin,regc.adminuser)
router.get('/userstatus/:id',regc.statusupdate)
router.get('/subupdate/:id',regc.subupdate)











module.exports=router
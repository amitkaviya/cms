function checksubscription(req,res,next){
if(req.session.sub=='subscribed'){
    next()
}else{
    res.render('suberror.ejs')
}

}

module.exports=checksubscription
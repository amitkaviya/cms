const mongoose=require('mongoose')


const regSchema=mongoose.Schema({
    email:String,
    password:String,
    firstName:String,
    lastName:String,
    dob:Date,
    gender:String,
    mobile:Number,
    img:{type:String,default:'avater.jpg'},
    status:{type:String,default:'suspended'},
    createdate:{type:String,default:new Date()},
    desc:String,
    sub:{type:String,default:'unsubscribed'}
})



module.exports=mongoose.model('reg',regSchema)
const Reg=require('../models/reg')
const bcrypt=require('bcrypt')
const nodemailer=require('nodemailer')


exports.loginpage=(req,res)=>{

    res.render('login.ejs',{message:''})
}

exports.regpage=(req,res)=>{
res.render('regterpage.ejs',{message:''})
}

exports.register=async(req,res)=>{
const{username,password}=req.body
const convertedpass= await bcrypt.hash(password,10)
const usercheck=await Reg.findOne({email:username})
//console.log(usercheck)
if(usercheck==null){
  const record=new Reg({email:username,password:convertedpass})
   record.save()
   const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    auth: {
      // TODO: replace `user` and `pass` values from <https://forwardemail.net>
      user: 'charanamit525@gmail.com',
      pass: 'Yzpctpoztirzrpqw'
    }
  });
  console.log('email connet successfully')
  console.log(record.id)
  const info = await transporter.sendMail({
    from:'charanamit525@gmail.com', // sender address
    to:username , // list of receivers
    subject:'email conformails', // Subject line
    text:'please click verfay to email', // plain text body
    html: `<a href=http://localhost:5000/emailverify/${record.id}>click to open email<a>`, // html body
  });

   res.render('regterpage.ejs',{message:" successfull accout create"})
}else{
  res.render('regterpage.ejs',{message:`this email id is already register ${username}`})
}
  //console.log(record)
}


exports.emailsendlink=async(req,res)=>{
  const id=req.params.id
  await Reg.findByIdAndUpdate(id,{status:'active'})
 res.render('emailverfymessage.ejs')

}


exports.logincheck=async(req,res)=>{
const{us,pass}=req.body
const record=await Reg.findOne({email:us})
if(record!==null){ 
  const passwordcheck=await bcrypt.compare(pass,record.password)
  if(passwordcheck){
    if(record.status=='suspended'){
      res.render('login',{message:'your email is not verfil pleas verfy'})
    }else{
      req.session.isAuth=true
      req.session.username=record.email
      req.session.userid=record.id
      req.session.sub=record.sub

  if(record.email=='admin@gmail.com'){
    res.redirect('/admin/dashboard')
  }else{
  res.redirect('/userprofiles')}
  }
}
else{
    res.render('login',{message:'wrong password'})
  }
}else{
  res.render('login.ejs',{message:"wrone cardinsan"})
}
}

exports.forgotform=(req,res)=>{
res.render('forgotform.ejs',{message:''})
}

exports.forgotsendlink=async(req,res)=>{
  const{us}=req.body
  const record=await Reg.findOne({email:us})
 // console.log(record)
 if(record!==null){
  const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    auth: {
      // TODO: replace `user` and `pass` values from <https://forwardemail.net>
      user: 'charanamit525@gmail.com',
      pass: 'Yzpctpoztirzrpqw'
    }
  });
  console.log('email connet successfully')
  const info = await transporter.sendMail({
    from:'charanamit525@gmail.com', // sender address
    to:us , // list of receivers
    subject:'password link change', // Subject line
    text:'please click to below link to change your password', // plain text body
    html: `<a href=http://localhost:5000/forgotpasswordlink/${record.id}>click to verfiy email<a>`, // html body
  });
  res.render('forgotlinkmessage.ejs')
 }else{
  res.render('forgotform.ejs',{message:'email not register with us'})
 }


}

exports.forgotpasslink=(req,res)=>{
console.log(req.params.id)
res.render('forgotpasswordform.ejs')
}

exports.forgotpasschange=async(req,res)=>{
  const{newpass}=req.body
  const id=req.params.id
  const cpass=await bcrypt.hash(newpass,10)
  await Reg.findByIdAndUpdate(id,{password:cpass})
  res.render('changepasswordmessage.ejs')

}



exports.logout=(req,res)=>{
req.session.destroy()
res.redirect('/')
}

exports.adminuser=async(req,res)=>{
  const username=req.session.username
  const record=await Reg.find()
res.render('admin/user.ejs',{username,record})
}

exports.statusupdate=async(req,res)=>{
const id=req.params.id
const record=await Reg.findById(id)
console.log(record)
let newStatus=null
if(record.status=='active'){
  newStatus='suspended'

}else{
  newStatus='active'
}
await Reg.findByIdAndUpdate(id,{status:newStatus})
res.redirect('/admin/user')
}


exports.userprofiles=async(req,res)=>{
  const username=req.session.username
  const record= await Reg.find({img:{$nin:['avater.jpg']}})
 //console.log(record)
res.render('userprofile.ejs',{username,record})
}

exports.profileupdateform=async(req,res)=>{
  const username=req.session.username
  const record=await Reg.findById(req.session.userid)
  //console.log(req.session.userid)
res.render('profileupdateform.ejs',{username,record,message:''}) 
}

exports.profileupdate= async(req,res)=>{
  const id=req.session.userid
  const username=req.session.username
  const record=await Reg.findById(req.session.userid)
const{fname,lname,dob,mobile,gender,about}=req.body
if(req.file){  
  const fiename=req.file.filename
await Reg.findByIdAndUpdate(id,{ firstName:fname,lastName:lname,dob:dob,gender:gender,mobile:mobile,img:fiename,desc:about})
}else{
await Reg.findByIdAndUpdate(id,{ firstName:fname,lastName:lname,dob:dob,gender:gender,mobile:mobile,desc:about})
}
res.render('profileupdateform.ejs',{message:'succfully updated',username,record})
}

exports.contactdetails=async(req,res)=>{
  const username=req.session.username
  const id=req.params.id
  const record=await Reg.findById(id)
  res.render('contactdetails.ejs',{username,record})

}

exports.subupdate=async(req,res)=>{
const id=req.params.id
const record=await Reg.findById(id)
let newsub=null
if(record.sub=='unsubscribed'){
  newsub='subscribed'

}else{
 newsub='unsubscribed'
}
await Reg.findByIdAndUpdate(id,{sub:newsub})
res.redirect('/admin/user')
}
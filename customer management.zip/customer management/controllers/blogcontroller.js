const Blog=require('../models/blog')


exports.blogselection=async(req,res)=>{
    const username=req.session.username
    const record=await Blog.find({email:username})
res.render('blog.ejs',{username,record})
}

exports.blogform= async(req,res)=>{
    const username=req.session.username
  res.render('blogform.ejs',{username})
}
exports.blogadd=(req,res)=>{
    const username=req.session.username
    const{title,blog}=req.body
     const record=new Blog({email:username,title:title,blog:blog})
     record.save()
     //console.log(record)
res.redirect('/yourblog')
     }
     exports.allblog=async(req,res)=>{
        const username=req.session.username
        const record= await Blog.find().sort({createDate:-1})
res.render('allblog.ejs',{username,record})
     }

    exports.blogdelete=async(req,res)=>{
        console.log(req.params.id)
        const record= await Blog.findByIdAndDelete(req.params.id)
        res.redirect('/yourblog')

    }

    exports.blogupdateform=async(req,res)=>{
        const username=req.session.username
        const record= await Blog.findById(req.params.id)
console.log(req.params.id)
res.render('blogupdateform.ejs',{username,record})
    }